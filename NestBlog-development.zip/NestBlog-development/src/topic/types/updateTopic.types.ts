export type UpdateTopicParams = {
  desc?:string,
  editors?:string[],
  viewers?:string[]
}