export type CreateTopicParams = {

  topic_name:string

  desc: string

  editors: string[]

  viewers: string[]

  topic_owner: string
}