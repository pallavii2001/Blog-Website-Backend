export type DeleteRoleParams = {
  userArr: string[]
  role: string
}