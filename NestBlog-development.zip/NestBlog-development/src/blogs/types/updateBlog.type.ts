export type UpdateBlogParams = {
  desc?:string,
  header?:string,
  body?:string,
  footer?:string
}