export type CreateBlogParams = {
  blog_name:string,
  desc:string,
  header: string,
  body:string,
  footer: string,
  topic:string,
  blog_owner:string
}