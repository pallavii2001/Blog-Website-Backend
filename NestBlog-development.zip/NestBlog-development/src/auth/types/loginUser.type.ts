export type LoginUserTypes = {
    username : string,
    password: string
} 
