export type ResetPassParams = {
  otp:number,
  username:string,
  password:string,
  confirm_password:string
}