export class modifyUser{
    username: string;
    level: number;
}