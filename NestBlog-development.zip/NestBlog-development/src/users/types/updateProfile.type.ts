export type UpdateProfileType = {
    name?: string;
    address ?: string;
    email?:string;
    phone?: number;
    password?: string;
}