export type ChangeLevelParams = {
  username:string,
  level:number
}