export type ChangePasswordType = {
    oldPassword:string;
    password: string;

}